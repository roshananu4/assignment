const hregisterBtn = document.getElementById('hregister');
hregisterBtn.addEventListener('click', function() {
  window.location.href = 'register.html';
});

const hloginBtn = document.getElementById('hlogin');
hloginBtn.addEventListener('click', function() {
  window.location.href = 'index.html';
});

const logoutBtn = document.getElementById('logout');
logoutBtn.addEventListener('click', function() {
  window.location.href = 'index.html';
});

const registerForm = document.getElementById("register-form");
registerForm.addEventListener("submit", registerUser);

const loginForm = document.getElementById("login-form");
loginForm.addEventListener("submit", loginUser);

const logoutButton = document.getElementById("logout");
logoutButton.addEventListener("click", logoutUser);

function registerUser(event) {
  event.preventDefault(); 

=  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (localStorage.getItem(username)) {
    alert("User already registered!");
    return;
  }

  localStorage.setItem(username, password);

  window.location.href = "index.html";
}

function loginUser(event) {
  event.preventDefault(); 

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (!localStorage.getItem(username)) {
    alert("User not registered!");
    return;
  }

  if (localStorage.getItem(username) !== password) {
    alert("Incorrect password!");
    return;
  }
  window.location.href = "home.html";
}

function logoutUser() {
  localStorage.removeItem("username");

  window.location.href = "index.html";
}
